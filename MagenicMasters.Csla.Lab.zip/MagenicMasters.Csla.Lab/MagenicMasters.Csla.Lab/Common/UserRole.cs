﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagenicMasters.CslaLab.Common
{
    internal static class UserRole
    {
        public static readonly string  Admins = "Administrator";
        public static readonly string  Customers = "Customers";
        public static readonly string Designers = "Desginers";
    }
}
